<?php
class ImportFile extends AppModel {
  public $belongsTo = array(
		'ImportFileType'
	);
}
?>
