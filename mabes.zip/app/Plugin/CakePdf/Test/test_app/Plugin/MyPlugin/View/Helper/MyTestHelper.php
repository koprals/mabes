<?php

App::uses('AppHelper', 'View/Helper');

class MyTestHelper extends AppHelper {

	public function dummyMethod() {
		return true;
	}
}