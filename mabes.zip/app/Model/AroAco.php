<?php
class AroAco extends AppModel
{
	var $useTable	=	"aros_acos";
}
?>