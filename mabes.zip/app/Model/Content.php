<?php
class Content extends AppModel {
}
?>
