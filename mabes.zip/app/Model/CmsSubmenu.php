<?php
class CmsSubmenu extends AppModel
{
}
?>